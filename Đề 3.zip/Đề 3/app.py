
from flask import Flask, render_template, request, url_for, jsonify
import json
import bcrypt
import sqlite3
from bcrypt import hashpw, gensalt


app = Flask(__name__)
DATABASE = 'db/ShoppingDB.db'

def connect_database():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template('index.html')

#Cau 2:
@app.route('/Supplier', methods = ['GET'])
def get_Supplier():
    conn = connect_database()
    cursor = conn.cursor()
    cursor.execute('SELECT rowid AS STT, SupplierName, EmailAddress, Tel, TotalEmployee FROM Supplier')
    suppliers = cursor.fetchall()
    conn.close()

    supplier_list = [
        {
            'STT': sup['STT'],
            'Name': sup['SupplierName'],
            'Email': sup['EmailAddress'],
            'Tel': sup['Tel'],
            'Total': sup['TotalEmployee']
        } for sup in suppliers
    ]
    return jsonify(supplier_list), 200

@app.route('/Supplier', methods=['DELETE'])
def delete_Supplier():
    supplierID = request.args.get('id')
    if not supplierID:
        return jsonify({'error': 'Thieu id'}), 400

    conn = connect_database()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM Supplier WHERE supplierID = ?', (supplierID,))
    conn.commit()

    if cursor.rowcount == 0:
        conn.close()
        return jsonify({'error': 'Not found id this Supplier'}), 404

    conn.close()
    return jsonify({'message': 'Deleted Successfully'})


#Cau 3:
@app.route('/Supplier', methods = ['POST'])
def add_Supplier():
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Missing JSON data'}), 400
    supplierName = data.get('supplierName')
    emailAddress = data.get('emailAddress')
    password = data.get('password')
    tel = data.get('tel')
    totalEmployee = data.get('totalEmployee')

    if supplierName and emailAddress and password and tel and totalEmployee:
        conn = connect_database()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO Supplier (supplierName,emailAddress,password,tel,totalEmployee) VALUES (?, ?, ?, ?, ?)',
                       (supplierName,emailAddress,password,tel,totalEmployee))
        new_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return jsonify({'new_id': new_id}), 201
    else:
        return jsonify({'error':'Thieu thong tin nha cung cap, vui long kiem tra lai'})

@app.route('/Supplier', methods=['PUT'])
def update_Supplier():
    data = request.get_json()
    supplierID = data.get('supplierID')
    if not supplierID:
        return jsonify({'error': 'Thiếu ID nhà cung cấp'}), 400

    emailAddress = data.get('emailAddress')
    password = data.get('password')
    tel = data.get('tel')

    # Kết nối cơ sở dữ liệu
    conn = connect_database()
    cursor = conn.cursor()

    # Lấy thông tin nhà cung cấp hiện tại
    existing_supplier = cursor.execute('SELECT * FROM Supplier WHERE supplierID = ?', (supplierID,)).fetchone()
    if not existing_supplier:
        conn.close()
        return jsonify({'error': 'Không tìm thấy Supplier với ID này'}), 404

    # Giữ nguyên giá trị cũ nếu không có giá trị mới
    emailAddress = emailAddress or existing_supplier['EmailAddress']
    password = hashpw(password.encode('utf-8'), gensalt()) if password else existing_supplier['Password']
    tel = tel or existing_supplier['Tel']

    # Kiểm tra dữ liệu cập nhật
    if not any([emailAddress, password, tel]):
        conn.close()
        return jsonify({'error': 'Không có trường nào để cập nhật'}), 400

    # Cập nhật dữ liệu
    cursor.execute(
        'UPDATE Supplier SET emailAddress = ?, password = ?, tel = ? WHERE supplierID = ?',
        (emailAddress, password, tel, supplierID)
    )
    conn.commit()

    if cursor.rowcount == 0:
        conn.close()
        return jsonify({'error': 'Không tìm thấy Supplier với ID này'}), 404

    conn.close()
    return jsonify({'message': 'Cập nhật thành công'}), 200

#Cau 4:Hãy tạo và mô tả hoạt động chi tiết của các method sau đây (comment đầy đủ vào từng hoạt động chính trong hàm):
#a) Tạo một method để nhận vào một EmailAddress và Password, Hàm này sẽ trả về Json
#của chỉ ra Supplier này có tồn tại trong CSDL hay không?
@app.route('/check_supplier', methods=['GET'])
def check_Supplier():
    """
    Nhận thông tin email và mật khẩu từ request, kiểm tra xem nhà cung cấp có tồn tại không.
    Hoạt động:
    1. Lấy emailAddress và password từ query params.
    2. Kiểm tra thông tin đầu vào:
        - Trả về lỗi nếu thiếu email hoặc password.
    3. Kết nối đến CSDL và tìm kiếm nhà cung cấp dựa trên email.
        - So sánh mật khẩu nhập vào với mật khẩu được mã hóa trong cơ sở dữ liệu.
    4. Trả về:
        - `exists: True` nếu nhà cung cấp tồn tại.
        - `exists: False` nếu không tồn tại.
    """
    emailAddress = request.args.get('emailAddress')
    password = request.args.get('password')

    if not emailAddress or not password:
        return jsonify({'error': 'Thiếu thông tin EmailAddress hoặc Password'}), 400

    conn = connect_database()
    cursor = conn.cursor()

    # Tìm kiếm supplier dựa vào email
    cursor.execute('SELECT supplierID, password FROM Supplier WHERE EmailAddress = ?', (emailAddress,))
    supplier = cursor.fetchone()
    conn.close()

    if supplier:
        hashed_password = supplier['password']  # Mật khẩu được mã hóa trong DB
        # Kiểm tra mật khẩu
        if bcrypt.checkpw(password.encode('utf-8'), hashed_password):
            return jsonify({'exists': True, 'supplierID': supplier['supplierID']}), 200
        else:
            return jsonify({'exists': False, 'error': 'Sai mật khẩu'}), 401
    else:
        return jsonify({'exists': False, 'error': 'Không tìm thấy nhà cung cấp'}), 404


# b) Tạo method để nhận vào một chuỗi tìm kiếm. Hàm này sẽ trả về Json của những bản ghi
# Supplier mà có thông tin hoặc là SupplierName, AccountName, EmailAddress gần đúng
# với nội dung chuỗi tìm kiếm.
@app.route('/search_supplier', methods=['GET'])
def search_Supplier():
    """
    Nhận một chuỗi tìm kiếm từ query params và tìm kiếm nhà cung cấp dựa trên:
    - SupplierName
    - AccountName
    - EmailAddress
    Hoạt động:
    1. Lấy từ khóa tìm kiếm từ query params.
    2. Kiểm tra thông tin đầu vào:
        - Trả về lỗi nếu thiếu từ khóa tìm kiếm.
    3. Kết nối đến CSDL và tìm kiếm nhà cung cấp gần đúng (sử dụng câu lệnh LIKE).
    4. Trả về danh sách các nhà cung cấp phù hợp (nếu có) hoặc thông báo không tìm thấy.
    """
    search_query = request.args.get('query')

    if not search_query:
        return jsonify({'error': 'Thiếu từ khóa tìm kiếm'}), 400

    conn = connect_database()
    cursor = conn.cursor()

    # Tìm kiếm gần đúng trong SupplierName, AccountName, hoặc EmailAddress
    cursor.execute('''
        SELECT rowid AS STT, SupplierName, EmailAddress, Tel, TotalEmployee 
        FROM Supplier 
        WHERE SupplierName LIKE ? OR EmailAddress LIKE ?''',
        (f'%{search_query}%', f'%{search_query}%'))
    suppliers = cursor.fetchall()
    conn.close()

    if not suppliers:
        return jsonify({'message': 'Không tìm thấy nhà cung cấp nào phù hợp'}), 404

    # Chuẩn bị danh sách kết quả
    supplier_list = [
        {
            'STT': sup['STT'],
            'Name': sup['SupplierName'],
            'Email': sup['EmailAddress'],
            'Tel': sup['Tel'],
            'Total': sup['TotalEmployee']
        } for sup in suppliers
    ]
    return jsonify(supplier_list), 200



@app.route('/products_by_supplier', methods=['GET'])
def get_products_by_supplier():
    """
    Nhận SupplierID và trả về danh sách sản phẩm thuộc về nhà cung cấp này.
    Hoạt động:
    1. Nhận SupplierID từ query params.
    2. Kiểm tra thông tin đầu vào:
       - Trả về lỗi nếu thiếu SupplierID.
    3. Kết nối cơ sở dữ liệu và lấy danh sách sản phẩm thuộc nhà cung cấp.
    4. Trả về danh sách sản phẩm hoặc thông báo không tìm thấy sản phẩm nào.
    """
    supplierID = request.args.get('SupplierID')

    if not supplierID:
        return jsonify({'error': 'Thiếu SupplierID'}), 400

    # Kết nối đến cơ sở dữ liệu
    conn = connect_database()
    cursor = conn.cursor()

    # Truy vấn danh sách sản phẩm
    cursor.execute('''
        SELECT ProductID, ProductName, Price, Stock 
        FROM Product 
        WHERE SupplierID = ?
    ''', (supplierID,))
    products = cursor.fetchall()
    conn.close()

    if not products:
        return jsonify({'message': 'Không có sản phẩm nào thuộc nhà cung cấp này'}), 404

    # Chuẩn bị danh sách sản phẩm
    product_list = [
        {
            'ProductID': product['ProductID'],
            'ProductName': product['ProductName'],
            'Price': product['Price'],
            'Stock': product['Stock']
        } for product in products
    ]

    return jsonify(product_list), 200


@app.route('/add_suppliers', methods=['POST'])
def add_suppliers():
    """
    Nhận vào danh sách các nhà cung cấp dưới dạng JSON và thêm vào cơ sở dữ liệu.
    Hoạt động:
    1. Nhận danh sách các nhà cung cấp từ body của request.
    2. Kiểm tra xem danh sách có trống hay không.
    3. Thực hiện thêm từng nhà cung cấp vào cơ sở dữ liệu.
    4. Trả về kết quả thành công hoặc lỗi.
    """
    data = request.get_json()  # Nhận dữ liệu từ body của yêu cầu

    if not data:
        return jsonify({'error': 'Thiếu dữ liệu đầu vào'}), 400

    # Kết nối cơ sở dữ liệu
    conn = connect_database()
    cursor = conn.cursor()

    # Duyệt qua từng nhà cung cấp trong danh sách
    for supplier in data:
        supplierName = supplier.get('supplierName')
        emailAddress = supplier.get('emailAddress')
        password = supplier.get('password')
        tel = supplier.get('tel')
        totalEmployee = supplier.get('totalEmployee')

        # Kiểm tra xem thông tin có đầy đủ không
        if not all([supplierName, emailAddress, password, tel, totalEmployee]):
            return jsonify({'error': 'Thiếu thông tin nhà cung cấp'}), 400

        # Thêm nhà cung cấp vào cơ sở dữ liệu
        cursor.execute('''
            INSERT INTO Supplier (SupplierName, EmailAddress, Password, Tel, TotalEmployee) 
            VALUES (?, ?, ?, ?, ?)
        ''', (supplierName, emailAddress, password, tel, totalEmployee))

    # Lưu các thay đổi vào cơ sở dữ liệu và đóng kết nối
    conn.commit()
    conn.close()

    return jsonify({'message': 'Đã thêm danh sách nhà cung cấp thành công'}), 201

#Cau 5:
@app.route('/suppliers')
def show_suppliers():
    # Gọi API hoặc lấy dữ liệu từ cơ sở dữ liệu
    conn = connect_database()
    cursor = conn.cursor()
    cursor.execute('SELECT rowid AS STT, SupplierName, EmailAddress, Tel, TotalEmployee FROM Supplier')
    suppliers = cursor.fetchall()
    conn.close()

    # Trả dữ liệu về dưới dạng list để render trên trang HTML
    return render_template('suppliers.html', suppliers=suppliers)


if __name__ == '__main__':
    app.run(debug=True)